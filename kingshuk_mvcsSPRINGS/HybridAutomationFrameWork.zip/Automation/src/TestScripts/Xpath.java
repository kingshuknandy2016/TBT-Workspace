package TestScripts;

public class Xpath {
	
	static String  searchBox = "//*[@id='SimpleSearchForm_SearchTerm']";
	static String  searchButton = "//*[@id='search-btn']";
	static String  searchResults = "//*[@id='Search_Result_Summary']/span[2]";

}
